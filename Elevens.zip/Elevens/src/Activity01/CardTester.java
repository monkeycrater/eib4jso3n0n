package src.Activity01;

/**
 * This is a class that tests the Card class.
 */
public class CardTester {

    /**
     * The main method in this class checks the Card operations for consistency.
     * 
     * @param args is not used.
     */
    public static void main(String[] args) {
        /* *** TO BE IMPLEMENTED IN ACTIVITY 1 *** */
        Card aceOfSpades = new Card("Ace", "Spade", 1);
        Card aceOfSpades1 = new Card("Ace", "Spade", 1);
        Card aceOfSpades2 = new Card("Ace", "Spade", 1);
        System.out.println(aceOfSpades.equals(aceOfSpades1));;
        System.out.println(aceOfSpades.toString());
        System.out.println("Stats for AceOfSpades2; Point value: " + aceOfSpades2.pointValue()+ " Suit: " + aceOfSpades2.suit() + " Rank: " + aceOfSpades2.rank());
    }
}
